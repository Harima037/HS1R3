<?php
class SysBitacora extends Eloquent
{
	protected $table = "sysBitacora";
	
	public $timestamps = false;
}	
?>