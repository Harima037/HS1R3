<?php
class SysDepartamento extends Eloquent
{
	protected $table = "sysDepartamentos";
}	
?>