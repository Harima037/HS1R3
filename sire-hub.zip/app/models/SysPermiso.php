<?php
class SysPermiso extends Eloquent
{
	protected $table = "sysPermisos";
}	
?>